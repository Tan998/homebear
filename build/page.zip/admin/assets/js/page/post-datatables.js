"use strict";

$(document).ready(function(){
  $('#table-list-posts').dataTable();
});