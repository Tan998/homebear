"use strict";

$(document).ready(function(){
  $('#contact-table').dataTable();
});