"use strict";

$(document).ready(function(){
  $('#download-materials-table').dataTable();
});